ColorPhun
===

<a href="https://play.google.com/store/apps/details?id=com.prakharme.prakharsriv.colorphun">
  <img alt="Get it on Google Play" src="http://developer.android.com/images/brand/en_generic_rgb_wo_45.png" />
</a>

ColorPhun is a simple color based Android Game.

### Features
- Google Play Services Integration
- Leaderboards
- Achievements

### Why Open-Source?

I have learnt a lot from the open code out there and this is my small token to repay the love. Hopefully, this will help another Android developer if they are on a quest to make a game.
You are free to fork and clone the way you want it. Just don't release the same app on the Play Store. In short, dont be a jerk.
